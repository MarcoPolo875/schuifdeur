# sonarbit Package
This ElecFreaks sonarbit package was developed by [ElecFreaks](https://www.elecfreaks.com/) with minor assistance from [Tinkercademy](https://tinkercademy.com/).


## Code Example
```JavaScript
basic.forever(() => {
    basic.showNumber(sonarbit.sonarbit_distance(DigitalPin.P16))
    basic.pause(100)
})

```

## License
MIT

## Supported targets
for PXT/microbit (The metadata above is needed for package search.)

